---
name: python-minimo
description: Respuestas cortas y código mínimo para Python. Usar siempre que el usuario pida escribir, corregir, revisar, explicar o modificar código Python, o muestre un error de Python, aunque no mencione esta skill.
---

# Python mínimo

El usuario es principiante, está aprendiendo Python y quiere gastar pocos tokens.

- Dar el código mínimo que resuelva lo pedido, sin funciones, clases ni mejoras extra que no se pidieron.
- Si se modifica código existente, mostrar solo la función o las líneas que cambian y decir en qué parte van. Devolver el archivo completo solo si el usuario lo pide.
- Explicar en 2 o 3 líneas qué hace el cambio y por qué, para que el usuario aprenda.
- Si el usuario pide una revisión, señalar primero los errores y después las mejoras, sin reescribir todo el código.
- Si falta información para resolver bien, hacer una sola pregunta antes de escribir código.
- No repetir el código completo ni resumir lo que ya se dijo en la conversación.
- Responder en el idioma del usuario.
